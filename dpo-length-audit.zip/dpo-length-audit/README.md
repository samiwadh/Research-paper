# Does DPO's gain survive length control?

**A controlled audit of Direct Preference Optimization (DPO) on a small open LLM.**

DPO is the most widely used preference-optimisation method for post-training LLMs.
A known worry is that part of its measured improvement is *length*: preference
datasets tend to prefer longer answers, reward-model judges also tend to prefer
longer answers, so a model that simply talks more can look "better" without being
better. This project measures how much of DPO's gain survives once length is
controlled for, and whether a length-regularised variant (R-DPO, Park et al. 2024)
changes the picture. It also checks whether the conclusion depends on which judge
you use.

This replicates a known effect. The contribution is rigour, not novelty:
pre-declared hypotheses and decision rules, three training seeds, two
independent reward-model judges, paired bootstrap confidence intervals, a
length-controlled win rate, and tracking of *likelihood displacement* (DPO
lowering the probability of the chosen answers too).

## Setup (all real, public components)

| Part | Choice | Why |
|---|---|---|
| Policy | `Qwen/Qwen2.5-0.5B-Instruct` + LoRA (r=16) | Fits a free Kaggle T4 (16 GB) |
| Preference data | `HuggingFaceH4/ultrafeedback_binarized` (`train_prefs`, `test_prefs`) | Standard DPO benchmark data |
| Methods | DPO (β=0.1), R-DPO (β=0.1, α=0.01) | Baseline vs length-regularised |
| Seeds | 0, 1, 2 (same data subset; seed changes order + LoRA init) | Separates optimisation noise from method effect |
| Judge 1 | `Skywork/Skywork-Reward-V2-Qwen3-0.6B` | Strong small reward model |
| Judge 2 | `OpenAssistant/reward-model-deberta-v3-large-v2` | Different family, checks judge sensitivity |
| Eval prompts | 300 held-out prompts from `test_prefs` | Never seen in training |

Check each model card before the full run; if a model has been renamed, change
it in `src/config.py`.

## Pre-declared hypotheses and decision rules

Written **before** running anything. Do not edit after seeing results; if you
change something, record it in a "Deviations" section.

- **H1 (DPO helps, raw):** DPO's raw win rate vs the base model is > 50%.
  *Supported* if the 95% bootstrap CI lower bound is > 50% in all 3 seeds, for both judges.
- **H2 (DPO lengthens):** DPO increases mean response length vs base.
  *Supported* if the paired 95% CI for Δlength excludes 0 in all 3 seeds.
- **H3 (gain shrinks under length control):** DPO's length-controlled (LC) win
  rate is lower than its raw win rate. *Supported* if LC < raw in all 3 seeds.
  If the LC CI includes 50%, conclude: *the gain is not distinguishable from a length effect*.
- **H4 (R-DPO trades less length for the same quality):** R-DPO has smaller Δlength
  than DPO and an LC win rate within 3 points of DPO's (mean over seeds).
- **H5 (judge robustness):** H1–H4 reach the same verdict under both judges.
  If they disagree, the disagreement *is* a finding: report it, do not pick the nicer judge.

Sanity checks (must pass before results count): unit tests green; training
reward accuracy rises above 0.5; no NaN losses; fraction of generations that
hit the token cap reported for every run (a high cap rate means length is
being truncated and Δlength is underestimated).

## How to run (Kaggle notebook, GPU T4, Internet ON)

```bash
!git clone <your-repo-url> && cd dpo-length-audit
!pip install -q -r requirements.txt
!python -m pytest -q tests          # step 0: tests must pass
!bash run_all.sh pilot              # ~1 h: 1 seed, 1000 pairs, 100 prompts. Check it works.
!bash run_all.sh full               # ~6-8 h total; you can split across sessions
```

Kaggle sessions stop after ~12 h and give ~30 GPU-hours a week. Copy the
`outputs/` folder to a Kaggle Dataset between sessions. Every script skips
work whose output already exists, so you can resume a stopped run.

## Repository map

```
src/config.py    all hyper-parameters in one place
src/data.py      dataset -> token ids + masks (+ length statistics of the data itself)
src/dpo.py       sequence log-probs, DPO / R-DPO loss (written from scratch, no TRL)
src/train.py     LoRA training loop: mixed precision, grad checkpointing, accumulation
src/generate.py  greedy generation on held-out prompts
src/score.py     reward-model scoring (two judges)
src/analyze.py   win rates, length-controlled win rate, bootstrap CIs, verdicts
tests/           unit tests for the maths (run offline, tiny random model)
LEARN.md         the theory behind every file, in the order to study it
```

## Results

*(fill in from `outputs/results.md` after the full run)*

## Deviations from the plan

*(none yet)*

## References

See the end of `LEARN.md`.
