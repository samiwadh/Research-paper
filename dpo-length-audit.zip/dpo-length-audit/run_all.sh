#!/usr/bin/env bash
# Usage: bash run_all.sh pilot   (1 seed, DPO only, small: checks the pipeline in ~1 h)
#        bash run_all.sh full    (3 seeds x {dpo, rdpo}; resumable)
set -euo pipefail
MODE=${1:-pilot}
if [ "$MODE" = "pilot" ]; then
  SEEDS="0"; METHODS="dpo"; NTRAIN="--n_train 1000"; NEVAL="--n_eval 100"; OUT=outputs_pilot
else
  SEEDS="0 1 2"; METHODS="dpo rdpo"; NTRAIN=""; NEVAL=""; OUT=outputs
fi
mkdir -p $OUT/gen

python -m src.generate --name base --out $OUT/gen/base.jsonl $NEVAL
for m in $METHODS; do
  for s in $SEEDS; do
    python -m src.train --method $m --seed $s --out $OUT/${m}_s${s} $NTRAIN
    python -m src.generate --name ${m}_s${s} --adapter $OUT/${m}_s${s} --out $OUT/gen/${m}_s${s}.jsonl $NEVAL
  done
done
for j in skywork oasst; do
  python -m src.score --judge $j --gen_dir $OUT/gen --out $OUT/scores_$j.jsonl
done
python -m src.analyze --scores $OUT/scores_skywork.jsonl $OUT/scores_oasst.jsonl --out $OUT/results.md
