"""Turn reward scores into the numbers that test H1-H5.

Usage:
    python -m src.analyze --scores outputs/scores_skywork.jsonl outputs/scores_oasst.jsonl \
                          --out outputs/results.md

For every trained run vs the base model, on the SAME prompts (paired design):
- Δlength: mean token difference, with paired bootstrap 95% CI
- raw win rate: P(reward_run > reward_base)
- length-controlled (LC) win rate: fit  P(win) = sigmoid(a + b * Δlen/100)  and report
  sigmoid(a) = predicted win rate for a pair with EQUAL lengths. Simplified version of
  the idea behind AlpacaEval-LC (Dubois et al. 2024); say so when you report it.
- judge length bias: Spearman correlation of reward with length on base outputs.
"""
import argparse
import json
from collections import defaultdict

import numpy as np

N_BOOT = 2000


def logistic_intercept(x, y, iters=50):
    """Fit y ~ sigmoid(a + b x) by Newton's method; return a. Small, dependency-free."""
    X = np.column_stack([np.ones_like(x), x])
    w = np.zeros(2)
    for _ in range(iters):
        p = 1 / (1 + np.exp(-X @ w))
        grad = X.T @ (y - p)
        H = X.T @ (X * (p * (1 - p))[:, None]) + 1e-6 * np.eye(2)   # tiny ridge for stability
        w += np.linalg.solve(H, grad)
    return w[0]


def sigmoid(a):
    return 1 / (1 + np.exp(-a))


def stats_for(base, run, rng):
    ids = sorted(set(base) & set(run))
    rb = np.array([base[i]["reward"] for i in ids])
    rr = np.array([run[i]["reward"] for i in ids])
    lb = np.array([base[i]["n_tokens"] for i in ids], float)
    lr = np.array([run[i]["n_tokens"] for i in ids], float)
    keep = rr != rb                                  # drop exact ties for the logistic fit
    win = (rr > rb).astype(float)
    dlen = (lr - lb) / 100.0

    def compute(idx):
        k = idx[keep[idx]]
        return ((lr[idx] - lb[idx]).mean(), win[idx].mean(),
                sigmoid(logistic_intercept(dlen[k], win[k])))

    point = compute(np.arange(len(ids)))
    boots = np.array([compute(rng.integers(0, len(ids), len(ids))) for _ in range(N_BOOT)])
    lo, hi = np.percentile(boots, [2.5, 97.5], axis=0)
    return {"n": len(ids), "dlen": point[0], "dlen_ci": (lo[0], hi[0]),
            "win": point[1], "win_ci": (lo[1], hi[1]),
            "lc_win": point[2], "lc_ci": (lo[2], hi[2]),
            "cap_rate": float(np.mean([run[i]["hit_cap"] for i in ids]))}


def spearman(a, b):
    ra, rb = np.argsort(np.argsort(a)), np.argsort(np.argsort(b))
    return float(np.corrcoef(ra, rb)[0, 1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scores", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    rng = np.random.default_rng(0)
    lines = ["# Results", ""]
    verdicts = {}

    for path in args.scores:
        judge = path.split("scores_")[-1].replace(".jsonl", "")
        by_run = defaultdict(dict)
        with open(path) as f:
            for r in map(json.loads, f):
                by_run[r["run"]][r["id"]] = r
        base = by_run.pop("base")
        bias = spearman([v["n_tokens"] for v in base.values()], [v["reward"] for v in base.values()])
        cap_base = np.mean([v["hit_cap"] for v in base.values()])
        lines += [f"## Judge: {judge}", "",
                  f"Judge length bias (Spearman reward~length on base outputs): **{bias:.2f}**  ",
                  f"Base cap rate: {cap_base:.1%}", "",
                  "| run | n | Δlen tokens [95% CI] | raw win [95% CI] | LC win [95% CI] | cap rate |",
                  "|---|---|---|---|---|---|"]
        res = {}
        for run in sorted(by_run):
            s = stats_for(base, by_run[run], rng)
            res[run] = s
            lines.append(f"| {run} | {s['n']} | {s['dlen']:+.0f} [{s['dlen_ci'][0]:+.0f}, {s['dlen_ci'][1]:+.0f}] "
                         f"| {s['win']:.1%} [{s['win_ci'][0]:.1%}, {s['win_ci'][1]:.1%}] "
                         f"| {s['lc_win']:.1%} [{s['lc_ci'][0]:.1%}, {s['lc_ci'][1]:.1%}] "
                         f"| {s['cap_rate']:.1%} |")
        # ---- decision rules from README ----
        dpo = [res[r] for r in res if r.startswith("dpo_")]
        rdpo = [res[r] for r in res if r.startswith("rdpo_")]
        v = {}
        if dpo:
            v["H1"] = all(s["win_ci"][0] > 0.5 for s in dpo)
            v["H2"] = all(s["dlen_ci"][0] > 0 for s in dpo)
            v["H3"] = all(s["lc_win"] < s["win"] for s in dpo)
            v["H3_lc_ci_includes_50"] = any(s["lc_ci"][0] <= 0.5 <= s["lc_ci"][1] for s in dpo)
        if dpo and rdpo:
            v["H4"] = (np.mean([s["dlen"] for s in rdpo]) < np.mean([s["dlen"] for s in dpo]) and
                       abs(np.mean([s["lc_win"] for s in rdpo]) - np.mean([s["lc_win"] for s in dpo])) <= 0.03)
        verdicts[judge] = v
        lines += ["", "Verdicts: " + ", ".join(f"{k}={'supported' if b else 'not supported'}"
                                             if not k.endswith("50") else f"{k}={b}" for k, b in v.items()), ""]

    if len(verdicts) == 2:
        a, b = verdicts.values()
        same = all(a.get(k) == b.get(k) for k in a)
        lines += ["## H5 (judge robustness)", "",
                  f"Both judges agree on every verdict: **{same}**", ""]
    with open(args.out, "w") as f:
        f.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
