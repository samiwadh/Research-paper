"""All experiment settings in one place.

Why one file: when you write the paper/README you must be able to say exactly
which settings produced which number. Scattered magic numbers make that impossible.
"""
from dataclasses import dataclass, field, asdict

POLICY_MODEL = "Qwen/Qwen2.5-0.5B-Instruct"
DATASET = "HuggingFaceH4/ultrafeedback_binarized"

JUDGES = {
    # name: (hf model id, input style)
    "skywork": ("Skywork/Skywork-Reward-V2-Qwen3-0.6B", "chat"),
    "oasst": ("OpenAssistant/reward-model-deberta-v3-large-v2", "pair"),
}


@dataclass
class TrainConfig:
    method: str = "dpo"          # "dpo" or "rdpo"
    seed: int = 0                # varies data ORDER and LoRA init
    data_seed: int = 0           # fixed: every run sees the SAME subset of pairs
    n_train: int = 4000          # preference pairs used for training
    max_len: int = 768           # prompt + response tokens; longer pairs are dropped, not truncated
    max_prompt_len: int = 256
    beta: float = 0.1            # DPO temperature: strength of the KL leash to the reference
    alpha: float = 0.01          # R-DPO length coefficient (ignored for plain DPO)
    lr: float = 2e-5
    batch_pairs: int = 2         # pairs per micro-batch (each pair = 2 sequences)
    grad_accum: int = 8          # effective batch = 2 * 8 = 16 pairs
    warmup_frac: float = 0.1
    max_grad_norm: float = 1.0
    lora_r: int = 16
    lora_alpha: int = 32
    lora_targets: list = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"])
    amp_dtype: str = "fp16"      # T4/P100 have no fast bf16; use "bf16" on A100/L4, "fp32" to debug
    log_every: int = 5           # optimizer steps

    def to_dict(self):
        return asdict(self)


@dataclass
class EvalConfig:
    n_eval: int = 300
    eval_seed: int = 0
    max_prompt_len: int = 256
    max_new_tokens: int = 768
    gen_batch: int = 16
