"""Turn UltraFeedback preference pairs into token tensors for DPO.

Each example in the dataset is (prompt, chosen answer, rejected answer).
For DPO we need, for each answer, the token ids of  prompt + answer  and a
*loss mask* that is 1 only on answer tokens: we score how likely the model is
to produce the ANSWER given the prompt, never how likely the prompt is.

Two design decisions that matter for this study:
1. Pairs that do not fit in max_len are DROPPED, not truncated. Truncation would
   cut long answers and hide exactly the length effect we want to measure.
2. We report how often the chosen answer is longer than the rejected one. That
   number is the root of DPO's length bias, so it belongs in the paper.
"""
import torch


def _encode_prompt(tokenizer, messages):
    # The chat template wraps messages in the model's special role tokens and
    # (add_generation_prompt=True) ends with the "assistant is speaking now" header.
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    return tokenizer(text, add_special_tokens=False)["input_ids"]


def _encode_response(tokenizer, text):
    # The answer must end with the end-of-turn token: the model should also learn WHEN to stop,
    # and stopping is precisely what controls length.
    return tokenizer(text, add_special_tokens=False)["input_ids"] + [tokenizer.eos_token_id]


def build_pairs(tokenizer, split, n, max_len, max_prompt_len, seed, dataset_name):
    from datasets import load_dataset  # imported here so tests do not need the library

    ds = load_dataset(dataset_name, split=split).shuffle(seed=seed)
    pairs = []
    stats = {"seen": 0, "dropped_tie": 0, "dropped_long_prompt": 0, "dropped_too_long": 0}
    for ex in ds:
        if len(pairs) >= n:
            break
        stats["seen"] += 1
        if ex["score_chosen"] == ex["score_rejected"]:
            stats["dropped_tie"] += 1      # no preference signal
            continue
        p_ids = _encode_prompt(tokenizer, ex["chosen"][:-1])
        if len(p_ids) > max_prompt_len:
            stats["dropped_long_prompt"] += 1
            continue
        c_ids = _encode_response(tokenizer, ex["chosen"][-1]["content"])
        r_ids = _encode_response(tokenizer, ex["rejected"][-1]["content"])
        if len(p_ids) + max(len(c_ids), len(r_ids)) > max_len:
            stats["dropped_too_long"] += 1
            continue
        pairs.append({
            "chosen_ids": p_ids + c_ids,
            "chosen_mask": [0] * len(p_ids) + [1] * len(c_ids),
            "rejected_ids": p_ids + r_ids,
            "rejected_mask": [0] * len(p_ids) + [1] * len(r_ids),
            "len_chosen": len(c_ids),
            "len_rejected": len(r_ids),
        })
    stats["kept"] = len(pairs)
    if pairs:
        stats["frac_chosen_longer"] = sum(p["len_chosen"] > p["len_rejected"] for p in pairs) / len(pairs)
        stats["mean_len_chosen"] = sum(p["len_chosen"] for p in pairs) / len(pairs)
        stats["mean_len_rejected"] = sum(p["len_rejected"] for p in pairs) / len(pairs)
    return pairs, stats


def collate(batch, pad_id):
    """Stack a list of pairs into ONE batch of 2B sequences: [chosen_1..B, rejected_1..B].

    One forward pass over 2B sequences is faster than two passes over B, and keeping
    chosen first / rejected second means we can split the outputs with [:B] and [B:].
    Padding is on the RIGHT (fine for training; generation needs LEFT padding).
    """
    seqs = [b["chosen_ids"] for b in batch] + [b["rejected_ids"] for b in batch]
    masks = [b["chosen_mask"] for b in batch] + [b["rejected_mask"] for b in batch]
    L = max(len(s) for s in seqs)
    n = len(seqs)
    input_ids = torch.full((n, L), pad_id, dtype=torch.long)
    attention_mask = torch.zeros((n, L), dtype=torch.long)
    loss_mask = torch.zeros((n, L), dtype=torch.long)
    for i, (s, m) in enumerate(zip(seqs, masks)):
        input_ids[i, :len(s)] = torch.tensor(s)
        attention_mask[i, :len(s)] = 1
        loss_mask[i, :len(s)] = torch.tensor(m)
    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "loss_mask": loss_mask,
        "len_chosen": torch.tensor([b["len_chosen"] for b in batch], dtype=torch.float),
        "len_rejected": torch.tensor([b["len_rejected"] for b in batch], dtype=torch.float),
    }
