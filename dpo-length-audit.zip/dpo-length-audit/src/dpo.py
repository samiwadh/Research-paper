"""The core maths: sequence log-probabilities and the DPO / R-DPO loss.

Written from scratch on purpose. Libraries like TRL do this for you, but in an
interview you will be asked to explain (or write) exactly these ~40 lines.
See LEARN.md sections 2 and 4-6 for the derivation.
"""
import torch
import torch.nn.functional as F


def sequence_logprobs(model, input_ids, attention_mask, loss_mask):
    """log p(answer | prompt) for every sequence in the batch.

    A causal LM outputs, at position t, a distribution over the token at t+1.
    So logits[:, t] are scored against input_ids[:, t+1]  -> the "shift by one".
    The mask is shifted the same way: we keep position t only if token t+1 is
    an answer token. Summing token log-probs = log of the product of token
    probabilities = log-probability of the whole answer (chain rule).
    """
    logits = model(input_ids=input_ids, attention_mask=attention_mask).logits
    logits = logits[:, :-1].float()            # fp32 for a numerically safe log-softmax
    targets = input_ids[:, 1:]
    mask = loss_mask[:, 1:].float()
    # log softmax(x)_k = x_k - logsumexp(x); gather first to avoid a 2nd vocab-sized tensor
    picked = torch.gather(logits, 2, targets.unsqueeze(-1)).squeeze(-1)
    token_logp = picked - torch.logsumexp(logits, dim=-1)
    return (token_logp * mask).sum(dim=-1)


def dpo_loss(pol_c, pol_r, ref_c, ref_r, beta, alpha=0.0, len_c=None, len_r=None):
    """DPO loss (Rafailov et al. 2023), optionally with the R-DPO length term (Park et al. 2024).

    pol_c / pol_r : log pi_theta(chosen|x), log pi_theta(rejected|x)       [B]
    ref_c / ref_r : same under the frozen reference model                     [B]

    Implicit reward of an answer: r(x, y) = beta * (log pi_theta(y|x) - log pi_ref(y|x)).
    Loss = -log sigmoid( r(x, y_chosen) - r(x, y_rejected) [+ alpha * (|y_c| - |y_r|)] ).

    R-DPO intuition: adding alpha * (length difference) to the margin gives the
    pair "free credit" when the chosen answer is longer, so the model does not need
    to learn "longer = better" to lower the loss. (Check sign/scale against eq. in
    Park et al. 2024 before writing it up.)
    """
    reward_c = beta * (pol_c - ref_c)
    reward_r = beta * (pol_r - ref_r)
    margin = reward_c - reward_r
    if alpha:
        margin = margin + alpha * (len_c - len_r)
    loss = -F.logsigmoid(margin).mean()
    with torch.no_grad():
        metrics = {
            "loss": loss.item(),
            "reward_acc": (reward_c > reward_r).float().mean().item(),
            "reward_margin": (reward_c - reward_r).mean().item(),
            "reward_chosen": reward_c.mean().item(),
            "reward_rejected": reward_r.mean().item(),
            # Likelihood displacement: if this goes NEGATIVE, DPO is making the chosen
            # answers LESS likely than before (it wins only by pushing rejected down faster).
            "delta_logp_chosen": (pol_c - ref_c).mean().item(),
            "delta_logp_rejected": (pol_r - ref_r).mean().item(),
        }
    return loss, metrics
