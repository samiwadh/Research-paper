"""Generate answers to held-out prompts, for the base model or a trained adapter.

Usage:
    python -m src.generate --name base --out outputs/gen/base.jsonl
    python -m src.generate --name dpo_s0 --adapter outputs/dpo_s0 --out outputs/gen/dpo_s0.jsonl

Greedy decoding: deterministic, so differences between runs come from the
weights, not sampling luck. We record whether each answer hit the token cap,
because a capped answer's true length is unknown (it would bias Δlength down).
"""
import argparse
import json
import os

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from src.config import POLICY_MODEL, DATASET, EvalConfig


def eval_prompts(tok, cfg):
    from datasets import load_dataset
    ds = load_dataset(DATASET, split="test_prefs").shuffle(seed=cfg.eval_seed)
    out = []
    for ex in ds:
        if len(out) >= cfg.n_eval:
            break
        msgs = ex["chosen"][:-1]
        text = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        if len(tok(text, add_special_tokens=False)["input_ids"]) <= cfg.max_prompt_len:
            out.append({"id": ex["prompt_id"], "messages": msgs, "text": text})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n_eval", type=int, default=None)
    ap.add_argument("--dtype", default="fp16", choices=["fp16", "bf16", "fp32"])
    args = ap.parse_args()
    if os.path.exists(args.out):
        print(f"{args.out} exists, skipping")
        return
    cfg = EvalConfig()
    if args.n_eval:
        cfg.n_eval = args.n_eval
    dtype = {"fp16": torch.float16, "bf16": torch.bfloat16, "fp32": torch.float32}[args.dtype]

    tok = AutoTokenizer.from_pretrained(POLICY_MODEL)
    tok.padding_side = "left"      # generation appends on the right, so padding must be on the left
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(POLICY_MODEL, torch_dtype=dtype).cuda()
    if args.adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, args.adapter).merge_and_unload()  # W + BA folded in
    model.eval()

    prompts = eval_prompts(tok, cfg)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    rows = []
    for i in range(0, len(prompts), cfg.gen_batch):
        chunk = prompts[i:i + cfg.gen_batch]
        enc = tok([p["text"] for p in chunk], return_tensors="pt", padding=True,
                  add_special_tokens=False).to("cuda")
        with torch.no_grad():
            gen = model.generate(**enc, max_new_tokens=cfg.max_new_tokens, do_sample=False,
                                 pad_token_id=tok.pad_token_id, eos_token_id=tok.eos_token_id)
        new = gen[:, enc["input_ids"].shape[1]:]
        for p, ids in zip(chunk, new):
            ids = ids.tolist()
            hit_eos = tok.eos_token_id in ids
            if hit_eos:
                ids = ids[:ids.index(tok.eos_token_id)]
            while ids and ids[-1] == tok.pad_token_id:
                ids.pop()
            rows.append({"id": p["id"], "run": args.name, "messages": p["messages"],
                         "response": tok.decode(ids, skip_special_tokens=True),
                         "n_tokens": len(ids), "hit_cap": not hit_eos})
        print(f"{args.name}: {len(rows)}/{len(prompts)}")
    with open(args.out, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")


if __name__ == "__main__":
    main()
