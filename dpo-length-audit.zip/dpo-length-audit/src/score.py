"""Score generated answers with a reward model (the "judge").

Usage:
    python -m src.score --judge skywork --gen_dir outputs/gen --out outputs/scores_skywork.jsonl

A reward model maps (prompt, answer) -> one number. It was itself trained on
human preferences, so it inherits their biases, including a preference for
length. That is why we use two judges from different families and also measure
each judge's own length bias in analyze.py.
"""
import argparse
import glob
import json
import os

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from src.config import JUDGES


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--judge", choices=list(JUDGES), required=True)
    ap.add_argument("--gen_dir", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    name, style = JUDGES[args.judge]

    done = set()
    if os.path.exists(args.out):
        with open(args.out) as f:
            done = {(r["run"], r["id"]) for r in map(json.loads, f)}

    tok = AutoTokenizer.from_pretrained(name)
    # fp32: judges are small, and fp16 can silently overflow on some architectures.
    rm = AutoModelForSequenceClassification.from_pretrained(name, num_labels=1,
                                                            torch_dtype=torch.float32).cuda().eval()
    out_f = open(args.out, "a")
    for path in sorted(glob.glob(os.path.join(args.gen_dir, "*.jsonl"))):
        with open(path) as f:
            rows = [json.loads(l) for l in f]
        for r in rows:
            if (r["run"], r["id"]) in done:
                continue
            if style == "chat":
                conv = r["messages"] + [{"role": "assistant", "content": r["response"]}]
                text = tok.apply_chat_template(conv, tokenize=False)
                if tok.bos_token and text.startswith(tok.bos_token):
                    text = text[len(tok.bos_token):]     # avoid a double BOS (see model card)
                enc = tok(text, return_tensors="pt", truncation=True, max_length=4096)
            else:  # "pair": (question, answer) as two segments, last user turn only
                question = [m for m in r["messages"] if m["role"] == "user"][-1]["content"]
                enc = tok(question, r["response"], return_tensors="pt", truncation=True, max_length=512)
            with torch.no_grad():
                score = rm(**enc.to("cuda")).logits[0][0].item()
            out_f.write(json.dumps({"run": r["run"], "id": r["id"], "reward": score,
                                    "n_tokens": r["n_tokens"], "hit_cap": r["hit_cap"]}) + "\n")
        out_f.flush()
        print(f"scored {path} with {args.judge}")
    out_f.close()


if __name__ == "__main__":
    main()
