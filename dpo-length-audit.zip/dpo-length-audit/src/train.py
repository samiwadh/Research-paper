"""Train a LoRA adapter on Qwen2.5-0.5B-Instruct with DPO or R-DPO.

Usage:
    python -m src.train --method dpo  --seed 0 --out outputs/dpo_s0
    python -m src.train --method rdpo --seed 0 --out outputs/rdpo_s0

Efficiency tricks used (each explained in LEARN.md section 8):
- LoRA: train ~1% of the parameters.
- Reference model for free: with LoRA, "adapter switched off" == the original model.
- Mixed precision (autocast) + loss scaling for fp16.
- Gradient checkpointing: recompute activations in backward instead of storing them.
- Gradient accumulation: effective batch 16 pairs with only 2 pairs in memory.
"""
import argparse
import json
import math
import os
import random
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, get_cosine_schedule_with_warmup
from peft import LoraConfig, get_peft_model

from src.config import POLICY_MODEL, DATASET, TrainConfig
from src.data import build_pairs, collate
from src.dpo import sequence_logprobs, dpo_loss

DTYPES = {"fp16": torch.float16, "bf16": torch.bfloat16, "fp32": torch.float32}


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--method", choices=["dpo", "rdpo"], default="dpo")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n_train", type=int, default=None)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    cfg = TrainConfig(method=args.method, seed=args.seed)
    if args.n_train:
        cfg.n_train = args.n_train
    if cfg.method == "dpo":
        cfg.alpha = 0.0
    if os.path.exists(os.path.join(args.out, "adapter_config.json")):
        print(f"{args.out} already trained, skipping")
        return
    os.makedirs(args.out, exist_ok=True)
    set_seed(cfg.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    amp_dtype = DTYPES[cfg.amp_dtype]
    use_amp = device == "cuda" and amp_dtype != torch.float32

    # ---- model ----
    tok = AutoTokenizer.from_pretrained(POLICY_MODEL)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(POLICY_MODEL, torch_dtype=torch.float32)
    model.config.use_cache = False                     # the KV cache is for generation only
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.enable_input_require_grads()                 # needed for checkpointing + frozen embeddings
    lora = LoraConfig(r=cfg.lora_r, lora_alpha=cfg.lora_alpha, lora_dropout=0.0,
                      target_modules=cfg.lora_targets, task_type="CAUSAL_LM")
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()
    model.to(device)
    model.train()

    # ---- data ----
    pairs, stats = build_pairs(tok, "train_prefs", cfg.n_train, cfg.max_len,
                               cfg.max_prompt_len, cfg.data_seed, DATASET)
    print("data stats:", stats)
    g = torch.Generator().manual_seed(cfg.seed)        # seed controls ORDER, data_seed controls SUBSET
    loader = DataLoader(pairs, batch_size=cfg.batch_pairs, shuffle=True, generator=g,
                        drop_last=True, collate_fn=lambda b: collate(b, tok.pad_token_id))
    total_steps = len(loader) // cfg.grad_accum

    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=cfg.lr, weight_decay=0.0)
    sched = get_cosine_schedule_with_warmup(opt, int(cfg.warmup_frac * total_steps), total_steps)
    scaler = torch.amp.GradScaler("cuda", enabled=(use_amp and amp_dtype == torch.float16))

    log_path = os.path.join(args.out, "train_log.jsonl")
    log_f = open(log_path, "w")
    running, step, t0 = [], 0, time.time()

    for micro, batch in enumerate(loader):
        batch = {k: v.to(device) for k, v in batch.items()}
        B = batch["len_chosen"].shape[0]
        fwd = dict(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"],
                   loss_mask=batch["loss_mask"])

        # Reference log-probs: same network, LoRA switched off, no gradients.
        with torch.no_grad(), model.disable_adapter(), \
                torch.autocast(device_type="cuda", dtype=amp_dtype, enabled=use_amp):
            ref = sequence_logprobs(model, **fwd)
        with torch.autocast(device_type="cuda", dtype=amp_dtype, enabled=use_amp):
            pol = sequence_logprobs(model, **fwd)

        loss, m = dpo_loss(pol[:B], pol[B:], ref[:B], ref[B:], cfg.beta, cfg.alpha,
                           batch["len_chosen"], batch["len_rejected"])
        if not math.isfinite(m["loss"]):
            raise RuntimeError(f"non-finite loss at micro-step {micro}; try amp_dtype='fp32'")
        scaler.scale(loss / cfg.grad_accum).backward()   # divide so accumulated grad = mean
        running.append(m)

        if (micro + 1) % cfg.grad_accum == 0:
            scaler.unscale_(opt)                          # clip the TRUE gradients, not scaled ones
            gnorm = torch.nn.utils.clip_grad_norm_(params, cfg.max_grad_norm).item()
            scaler.step(opt)
            scaler.update()
            opt.zero_grad(set_to_none=True)
            sched.step()
            step += 1
            if step % cfg.log_every == 0 or step == total_steps:
                avg = {k: float(np.mean([r[k] for r in running])) for k in running[0]}
                avg.update(step=step, total=total_steps, grad_norm=gnorm,
                           lr=sched.get_last_lr()[0], min_elapsed=(time.time() - t0) / 60)
                log_f.write(json.dumps(avg) + "\n")
                log_f.flush()
                print({k: round(v, 4) if isinstance(v, float) else v for k, v in avg.items()})
                running = []
            if step >= total_steps:
                break

    log_f.close()
    model.save_pretrained(args.out)                       # saves only the LoRA weights (a few MB)
    with open(os.path.join(args.out, "run_info.json"), "w") as f:
        json.dump({"config": cfg.to_dict(), "data_stats": stats, "model": POLICY_MODEL}, f, indent=2)


if __name__ == "__main__":
    main()
