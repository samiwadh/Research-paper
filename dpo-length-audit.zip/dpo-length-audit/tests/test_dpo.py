"""Unit tests for the maths. Run offline: they build a tiny RANDOM model, no download.

Run with:  python -m pytest -q tests
Testing the loss before training is what separates a research codebase from a
script: a sign error in DPO still "trains", it just learns the wrong thing.
"""
import math

import torch
from transformers import LlamaConfig, LlamaForCausalLM

from src.dpo import sequence_logprobs, dpo_loss
from src.data import collate


def tiny_model():
    torch.manual_seed(0)
    cfg = LlamaConfig(vocab_size=50, hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                      num_attention_heads=4, num_key_value_heads=4, max_position_embeddings=64)
    return LlamaForCausalLM(cfg).eval()


def test_logprobs_match_manual_loop():
    """The shift-by-one and the mask must select exactly the answer tokens."""
    model = tiny_model()
    ids = torch.randint(0, 50, (1, 10))
    loss_mask = torch.tensor([[0, 0, 0, 0, 1, 1, 1, 1, 1, 1]])   # prompt = first 4 tokens
    attn = torch.ones_like(ids)
    got = sequence_logprobs(model, ids, attn, loss_mask)
    with torch.no_grad():
        logp = model(input_ids=ids).logits.log_softmax(-1)
    manual = sum(logp[0, t - 1, ids[0, t]] for t in range(4, 10))  # token t predicted at t-1
    assert torch.allclose(got, manual.unsqueeze(0), atol=1e-5)


def test_right_padding_does_not_change_logprobs():
    model = tiny_model()
    ids = torch.randint(1, 50, (1, 8))
    m = torch.tensor([[0, 0, 0, 1, 1, 1, 1, 1]])
    a = sequence_logprobs(model, ids, torch.ones_like(ids), m)
    pad = torch.zeros((1, 4), dtype=torch.long)
    ids_p, m_p = torch.cat([ids, pad], 1), torch.cat([m, pad], 1)
    attn_p = torch.cat([torch.ones_like(ids), pad], 1)
    b = sequence_logprobs(model, ids_p, attn_p, m_p)
    assert torch.allclose(a, b, atol=1e-5)


def test_loss_is_log2_when_policy_equals_reference():
    x = torch.randn(4)
    y = torch.randn(4)
    loss, m = dpo_loss(x, y, x, y, beta=0.1)
    assert abs(loss.item() - math.log(2)) < 1e-6
    assert m["reward_margin"] == 0


def test_gradient_pushes_chosen_up_and_rejected_down():
    pol_c = torch.zeros(3, requires_grad=True)
    pol_r = torch.zeros(3, requires_grad=True)
    loss, _ = dpo_loss(pol_c, pol_r, torch.zeros(3), torch.zeros(3), beta=0.1)
    loss.backward()
    assert (pol_c.grad < 0).all()   # gradient DESCENT increases log p(chosen)
    assert (pol_r.grad > 0).all()   # ...and decreases log p(rejected)


def test_rdpo_gives_credit_when_chosen_is_longer():
    z = torch.zeros(2)
    base, _ = dpo_loss(z, z, z, z, beta=0.1)
    rd, _ = dpo_loss(z, z, z, z, beta=0.1, alpha=0.01,
                     len_c=torch.tensor([300.0, 300.0]), len_r=torch.tensor([100.0, 100.0]))
    assert rd.item() < base.item()


def test_collate_layout():
    pair = {"chosen_ids": [1, 2, 3], "chosen_mask": [0, 1, 1],
            "rejected_ids": [1, 4], "rejected_mask": [0, 1],
            "len_chosen": 2, "len_rejected": 1}
    b = collate([pair, pair], pad_id=0)
    assert b["input_ids"].shape == (4, 3)               # 2 chosen then 2 rejected
    assert b["input_ids"][2].tolist() == [1, 4, 0]      # rejected, right-padded
    assert b["attention_mask"][2].tolist() == [1, 1, 0]
    assert b["loss_mask"][0].tolist() == [0, 1, 1]
